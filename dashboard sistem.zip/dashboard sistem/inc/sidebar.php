        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="nk-sidebar">           
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                    <?php if(!isset($_GET['page']) || $_GET['page'] == "dashboard"){ ?>
                        <li class="nav-label">
                            <i id="status" style="color:red;">Terputus</i>
                        </li>
                    <?php } ?>
                    <li class="nav-label">Dashboard</li>
                    
                    <li>
                        <a href="./." aria-expanded="false">
                            <i class="icon-speedometer menu-icon"></i><span class="nav-text">Dashboard</span>
                        </a>
                    </li>   
                    <li>
                        <a href="?page=user" aria-expanded="false">
                            <i class="icon-user"></i><span class="nav-text">Pengguna</span>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php" aria-expanded="false">
                            <i class="icon-key"></i><span class="nav-text">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->