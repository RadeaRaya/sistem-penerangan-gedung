<?php
  session_start();

  if(!isset($_SESSION['username'])){
    echo "<script> location.href='login.php' </script>";
  }

  include "config/database.php";
  include "inc/header.php";
  include "inc/navbar.php";
  include "inc/sidebar.php";
  include "inc/alerts.php";

  if(isset($_GET['page'])){
    $page = $_GET['page'];
    include "page/". $page .".php";
  } else {
    include "page/dashboard.php";
  }

  include "inc/footer.php";
  ?>
</div>
    <!--**********************************
        Scripts
    ***********************************-->
    <script src="theme/plugins/common/common.min.js"></script>
    <script src="theme/js/custom.min.js"></script>
    <script src="theme/js/settings.js"></script>
    <script src="theme/js/gleek.js"></script>
    <script src="theme/js/styleSwitcher.js"></script>

    <!-- Chartjs -->
    <script src="theme/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Circle progress -->
    <script src="theme/plugins/circle-progress/circle-progress.min.js"></script>
    <!-- Datamap -->
    <script src="theme/plugins/d3v3/index.js"></script>
    <script src="theme/plugins/topojson/topojson.min.js"></script>
    <script src="theme/plugins/datamaps/datamaps.world.min.js"></script>
    <!-- Morrisjs -->
    <script src="theme/plugins/raphael/raphael.min.js"></script>
    <script src="theme/plugins/morris/morris.min.js"></script>
    <!-- Pignose Calender -->
    <script src="theme/plugins/moment/moment.min.js"></script>
    <script src="theme/plugins/pg-calendar/js/pignose.calendar.min.js"></script>
    <!-- ChartistJS -->
    <script src="theme/plugins/chartist/js/chartist.min.js"></script>
    <script src="theme/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js"></script>



    <script src="theme/js/dashboard/dashboard-1.js"></script>
    <script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });
</script>


</script>


</body>

</html>
