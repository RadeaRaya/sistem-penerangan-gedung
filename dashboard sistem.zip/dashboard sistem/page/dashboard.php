<?php

$sql = "SELECT * FROM devices WHERE active = 'Yes'";
$result = mysqli_query($conn, $sql);

?>

    <!--**********************************
        Main wrapper start
    ***********************************-->
            
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-1">
                            <div class="card-body">
                                <h3 class="card-title text-white">relay 1</h3>
                                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                    <label class="btn btn-primary" id="label-relay1-on">
                                        <input type="radio" name="relay1" onchange="publishrelay1(this)" id="relay1-on" autocomplete="off"> on
                                    </label>
                                    <label class="btn btn-primary" id="label-relay1-off">
                                        <input type="radio" name="relay1" onchange="publishrelay1(this)" id="relay1-off" autocomplete="off"> off
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-2">
                            <div class="card-body">
                                <h3 class="card-title text-white">relay 2</h3>
                                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                    <label class="btn btn-primary" id="label-relay2-on">
                                        <input type="radio" name="relay2" onchange="publishrelay2(this)" id="relay2-on" autocomplete="off"> on
                                    </label>
                                    <label class="btn btn-primary" id="label-relay2-off">
                                        <input type="radio" name="relay2" onchange="publishrelay2(this)" id="relay2-off" autocomplete="off"> off
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-3">
                            <div class="card-body">
                                <h3 class="card-title text-white">relay 3</h3>
                                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                <label class="btn btn-primary" id="label-relay3-on">
                                    <input type="radio" name="relay3" onchange="publishrelay3(this)" id="relay3-on" autocomplete="off"> on
                                </label>
                                <label class="btn btn-primary" id="label-relay3-off">
                                    <input type="radio" name="relay3" onchange="publishrelay3(this)" id="relay3-off" autocomplete="off"> off
                                </label>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-4">
                            <div class="card-body">
                                <h3 class="card-title text-white"> relay 4</h3>
                                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                <label class="btn btn-primary" id="label-relay4-on">
                                    <input type="radio" name="relay4" onchange="publishrelay4(this)" id="relay4-on" autocomplete="off"> on
                                </label>
                                <label class="btn btn-primary" id="label-relay4-off">
                                    <input type="radio" name="relay4" onchange="publishrelay4(this)" id="relay4-off" autocomplete="off"> off
                                </label>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>

    
    <!--**********************************
        Main wrapper end
    ***********************************-->

<script src="https://unpkg.com/mqtt/dist/mqtt.min.js"></script>

<script>
    const clientId = Math.random().toString(16).substr(2, 8);
    const host = "wss://broker.emqx.io:8084/mqtt";

    const options = {
        keepalive: 30,
        clientId: clientId,
        protocolId: 'MQTT',
        protocolVersion: 4,
        clean: true,
        reconnectPeriod: 1000,
        connectTimeout: 30 * 1000,
    };

    console.log("Menghubungkan ke Broker");
    const client = mqtt.connect(host, options);

    client.on("connect", ()=>{
        console.log("Terhubung");
        document.getElementById("status").innerHTML = "Terhubung";
        document.getElementById("status").style.color = "blue";

        client.subscribe("tobrut/#", {qos: 1});
    });

    client.on("message", function(topic, payload){
        if(topic === "tobrut/87654321/relay1"){
            if(payload == "on"){
                document.getElementById("label-relay1-on").classList.add("active");
                document.getElementById("label-relay1-off").classList.remove("active");
            } else {
                document.getElementById("label-relay1-on").classList.remove("active");
                document.getElementById("label-relay1-off").classList.add("active");
            }
        }
        if(topic === "tobrut/87654321/relay2"){
            if(payload == "on"){
                document.getElementById("label-relay2-on").classList.add("active");
                document.getElementById("label-relay2-off").classList.remove("active");
            } else {
                document.getElementById("label-relay2-on").classList.remove("active");
                document.getElementById("label-relay2-off").classList.add("active");
            }
        }
        if(topic === "tobrut/87654321/relay3"){
            if(payload == "on"){
                document.getElementById("label-relay3-on").classList.add("active");
                document.getElementById("label-relay3-off").classList.remove("active");
            } else {
                document.getElementById("label-relay3-on").classList.remove("active");
                document.getElementById("label-relay3-off").classList.add("active");
            }
        }
        if(topic === "tobrut/87654321/relay4"){
            if(payload == "on"){
                document.getElementById("label-relay4-on").classList.add("active");
                document.getElementById("label-relay4-off").classList.remove("active");
            } else {
                document.getElementById("label-relay4-on").classList.remove("active");
                document.getElementById("label-relay4-off").classList.add("active");
            }
        }

        if(topic.includes("tobrut/status/")){
            document.getElementById(topic).innerHTML = payload;

            if(payload.toString() === "offline"){
                document.getElementById(topic).style.color = "red";
            } else if(payload.toString() === "online"){
                document.getElementById(topic).style.color = "blue";
            }
        }
    });

    function publishrelay1(value){
        if(document.getElementById("relay1-on").checked){
            data = "on";
        }

        if(document.getElementById("relay1-off").checked){
            data = "off";
        }

        client.publish("tobrut/87654321/relay1", data, {qos:1, retain:true});
    }
    
    function publishrelay2(value){
        if(document.getElementById("relay2-on").checked){
            data = "on";
        }

        if(document.getElementById("relay2-off").checked){
            data = "off";
        }

        client.publish("tobrut/87654321/relay2", data, {qos:1, retain:true});
    }
    function publishrelay3(value){
        if(document.getElementById("relay3-on").checked){
            data = "on";
        }

        if(document.getElementById("relay3-off").checked){
            data = "off";
        }

        client.publish("tobrut/87654321/relay3", data, {qos:1, retain:true});
    }
    function publishrelay4(value){
        if(document.getElementById("relay4-on").checked){
            data = "on";
        }

        if(document.getElementById("relay4-off").checked){
            data = "off";
        }

        client.publish("tobrut/87654321/relay4", data, {qos:1, retain:true});
    }

</script>